Imágenes de los apuntes de Javascript
