# Bloc 1: Javascript. UT 6: Eventos

## 6.1 Ejercicios cortos

### 6.1.a: borrador
Llena una página con párrafos de texto y qye cuando el ratón pase por encima de cada uno cambiará su color a rojo y cuando salga del párrafo desaparecerá. La página incluirá un botón que al pulsarlo vuelve a mostrar todo el texto.

### 6.1.b: ventana huidiza
Haz qur tu página abra ua pequeña ventana de 200x150px que cuando pase el ratón por ella cambie su posición a otro sitio

### 6.1.c: calculadora
Haz una pequeña calculadora con botones para los 10 números más borrar, +, -, *, / y =.

