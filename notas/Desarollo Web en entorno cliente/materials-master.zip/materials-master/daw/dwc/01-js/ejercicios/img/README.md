# Imágenes de los ejercicios
