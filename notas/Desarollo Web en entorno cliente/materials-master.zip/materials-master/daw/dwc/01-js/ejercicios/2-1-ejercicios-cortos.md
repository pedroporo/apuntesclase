# Bloc 1: Javascript. UT 2: Arrays

## 2.1 Ejercicios cortos
Aquí tenéis varios ejercicios que podéis hacer para practicar arrays de Javascript.

### Ejercicio 2.1.a: estadísticas de letras
Crea una página que contenga una función a la que se le pasa como parámetro una cadena de texto y que muestre en la consola el nº de veces que aparece cada letra.
