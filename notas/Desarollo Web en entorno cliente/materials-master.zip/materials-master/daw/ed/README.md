# Entorns de Desenvolupament

## 1. Unitats Didàctiques

1. Desenvolupament de Programari
2. IDEs
3. Sistema de Control de Versions (SCV) Git
4. Metodologies de Desenvolupament. Eines de gestió de Projectes
5. [Modelat de Projectes amb UML](UD5/README.md)
6. Refactorització i Documentació
7. Proves i Qualitat del Programari
8. Projecte Integradori
