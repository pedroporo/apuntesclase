# Virtualització. Virtualbox
Ací explicarem què és la Virtualització i com utilitzar l'aplicació Virtualbox per a crear màquines virtuals.

## Índex
1. [Virtualització](./virtualitzacio-hw.md)
2. [VirtualBox](./virtualbox.md)
