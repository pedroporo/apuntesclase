# Scripts en Linux
- [Scripts en Linux](#scripts-en-linux)
  - [Introducción](#introducción)
  - [Leer datos de un fichero](#leer-datos-de-un-fichero)

## Introducción

## Leer datos de un fichero
[Leer datos de un fichero](./leerDatos.md)
