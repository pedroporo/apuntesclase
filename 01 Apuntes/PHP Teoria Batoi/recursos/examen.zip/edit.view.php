<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Formulari Cicles</title>
    <!-- Afegeix aquí els teus enllaços a CSS o JavaScript si n'hi ha -->
</head>
<body>
<?php
    include_once $_SERVER['DOCUMENT_ROOT'].'/view/header.view.php';
?>
<form action="updateCourse.php" method="post">
    <input type="hidden" name="id">
    <!-- Camp Cycle -->
    <label for="cycle">Cycle:</label>
    <input type="text" id="cycle" name="cycle">
    <br/>

    <!-- Camp vliteral -->
    <label for="vliteral">Vliteral:</label>
    <input type="text" id="vliteral" name="vliteral">
    <br/>

    <!-- Camp cliteral -->
    <label for="cliteral">Cliteral:</label>
    <input type="text" id="cliteral" name="cliteral">
    <br/>

    <!-- Botó de Submit -->
    <input type="submit" value="Guardar">
</form>
</body>
</html>

