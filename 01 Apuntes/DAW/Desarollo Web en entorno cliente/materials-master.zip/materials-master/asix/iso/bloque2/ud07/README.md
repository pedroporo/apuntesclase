# Bl2. UD 7 - Supervisión y monitorización del sistema

## Contenidos
Los contenidos de esta unidad son los siguientes:
1. [Supervisión y monitorización del sistema](introd.md)
2. [Supervisión del sistema en Windows](supervision-win.md)
3. [Auditoría del sistema en Windows](auditoria-win.md)
4. [Registros de eventos en Windows](logs-win.md)

## Conceptos clave
Los conceptos más importantes de esta unidad son:
- Rendimiento y monitorización

## Conocimiento previo
Antes de comenzar esta unidad de trabajo el alumno debería saber:
- cómo configurar el sistema informático
- cómo utilizar la terminal para realizar tareas básicas en una máquina

## Caso práctico

## Bibliografía
- Sergi Coll. Sistemes Operatius en Xarxa. [https://sergi-coll.gitbook.io/sox/](https://sergi-coll.gitbook.io/sox/) (consultat sep-22)