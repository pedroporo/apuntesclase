# Bloc 1: Javascript. UT 5: BOM

## 5.1 Ejercicios cortos
Aquí tenéis varios ejercicios que podéis hacer para practicar.

### Ejercicio 5.1.a: reloj
Haz que en alguna parte de la página aparezca la hora actual, que se irá actualizando cada segundo.

### Ejercicio 5.1.b: navigator
Muestra toda la información sobre el navegador que se utiliza para ver la página.

### Ejercicio 5.1.c: ventana movediza
Haz una página que abrirá en la esquina superior izquierda de la pantalla una pequeña ventana de 200x150 px con el texto “Me muevo” que irá desplazándose poco a poco por los bordes de la ventana padre (al llegar a la derecha comenzará a bajar, al llegar abajo se moverá a la izquierda, ...). 

NOTA: no es necesario que se mueva "exactamente" por el borde ya que según el navegador cuenta o no la barra de estado, del título, ... Simplemente que vaya dando vueltas por la ventana padre "más o menos" por sus bordes.

