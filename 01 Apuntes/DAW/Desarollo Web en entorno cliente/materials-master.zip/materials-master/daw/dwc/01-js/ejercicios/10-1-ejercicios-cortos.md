# Bloc 1: Javascript. UT 10: APIs Javascript

## 10.1 Ejercicios cortos

### 10.1.a: puzzle (difícil)
Vamos a hacer un juego de un puzle con una tabla de 4x4 y 15 imágenes (torzos de 1 imagen) más un hueco para el movimiento. Las imágenes aparecerán colocadas al azar y debes ir movúendolas para completar el puzle. Sólo puede moverse a la celda en blanco la imagen que hay a su izquierda, suderecha, arriba o abajo.

