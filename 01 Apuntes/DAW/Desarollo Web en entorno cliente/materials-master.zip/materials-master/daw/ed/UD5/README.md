# UD5: Modelat de Projectes amb UML

## 1. Continguts

1. Modelat Orientat a Objectes
2. Diagrama de Casos d'Ús (DCU)
   1. Exemple DCU - Sencill
3. Diagrama de Seqüència
4. Diagrama de Classes
5. Altres Diagrames UML

## 2. Activitats

1. [UD5 - P1 - Diagrama de Casos d'ús](https://drive.google.com/file/d/1oN1GfT4uNo6Fb-ocx5sKvB2v6_MPBXDK/view?usp=sharing)
2. [UD5 - P2 - Diagrama de Seqüència 1/2](https://drive.google.com/file/d/1uSFAtkgiSIsbwByKZyFBV21kgS3rOo24/view?usp=sharing)

## 3. Material extra

* [Exemple de sol·lució del primer exercici de casos d'ús](UD5-PRAC1-SOL-CASUS.md)